# GLOBABOX – pre-deployment security checklist

This is a backup of the previously supplied source, NOT a production-hardened deployment.

- Replace the browser-side `VITE_ADMIN_PASSWORD` authentication with actual server-side administrator authentication. VITE_ variables are exposed to site visitors.
- Protect POST/PUT/DELETE product endpoints and order administration on the server with session/role authorization.
- Validate all request bodies and configure rate limiting and access policies.
- Move catalog/order storage to a persistent database before production hosting (current JSON files are local to the server).
- Keep `.env`, secrets, customer data, and credentials out of git.
- Test all ordering flows and backups before pointing the live domain at this code.
- The Lovable project code is different from this older backup and has NOT been merged.
